// SPDX-License-Identifier: LicenseRef-Highcharts
/**
 * @license Highcharts JS v13.0.0-beta.1 (2026-05-19)
 * @module highcharts/themes/adaptive
 * @requires highcharts
 *
 * (c) 2009-2026 Highsoft AS
 * Author: Torstein Hønsi
 *
 * A commercial license may be required depending on use,
 * see www.highcharts.com/license
 */
(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(root["_Highcharts"], root["_Highcharts"]["Chart"]);
	else if(typeof define === 'function' && define.amd)
		define("highcharts/themes/adaptive", ["highcharts/highcharts"], function (amd1) {return factory(amd1,amd1["Chart"]);});
	else if(typeof exports === 'object')
		exports["highcharts/themes/adaptive"] = factory(root["_Highcharts"], root["_Highcharts"]["Chart"]);
	else
		root["Highcharts"] = factory(root["Highcharts"], root["Highcharts"]["Chart"]);
})(typeof window === 'undefined' ? this : window, (__WEBPACK_EXTERNAL_MODULE__944__, __WEBPACK_EXTERNAL_MODULE__960__) => {
return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 944:
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__944__;

/***/ }),

/***/ 960:
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__960__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ adaptive_src)
});

// EXTERNAL MODULE: external {"amd":["highcharts/highcharts"],"commonjs":["highcharts"],"commonjs2":["highcharts"],"root":["Highcharts"]}
var highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_ = __webpack_require__(944);
var highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default = /*#__PURE__*/__webpack_require__.n(highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_);
// EXTERNAL MODULE: external {"amd":["highcharts/highcharts","Chart"],"commonjs":["highcharts","Chart"],"commonjs2":["highcharts","Chart"],"root":["Highcharts","Chart"]}
var highcharts_Chart_commonjs_highcharts_Chart_commonjs2_highcharts_Chart_root_Highcharts_Chart_ = __webpack_require__(960);
var highcharts_Chart_commonjs_highcharts_Chart_commonjs2_highcharts_Chart_root_Highcharts_Chart_default = /*#__PURE__*/__webpack_require__.n(highcharts_Chart_commonjs_highcharts_Chart_commonjs2_highcharts_Chart_root_Highcharts_Chart_);
;// ./code/es-modules/Shared/Utilities.js
/* *
 *
 *  (c) 2009-2026 Highsoft AS
 *
 *  Integration of this software requires a license.
 *  - For commercial use, see www.highcharts.com/license
 *  - For non-commercial, see www.highcharts.com/license-eula
 *
 *
 * */

const { doc, win } = (highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default());
/**
 * Add an event listener.
 *
 * @function Highcharts.addEvent<T>
 *
 * @param  {Highcharts.Class<T>|T} el
 *         The element or object to add a listener to. It can be a
 *         {@link HTMLDOMElement}, an {@link SVGElement} or any other object.
 *
 * @param  {string} type
 *         The event type.
 *
 * @param  {Highcharts.EventCallbackFunction<T>|Function} fn
 *         The function callback to execute when the event is fired.
 *
 * @param  {Highcharts.EventOptionsObject} [options]
 *         Options for adding the event.
 *
 * @sample highcharts/members/addevent
 *         Use a general `render` event to draw shapes on a chart
 *
 * @return {Function}
 *         A callback function to remove the added event.
 */
function addEvent(el, type, fn, options = {}) {
    // Add hcEvents to either the prototype (in case we're running addEvent on a
    // class) or the instance. If hasOwnProperty('hcEvents') is false, it is
    // inherited down the prototype chain, in which case we need to set the
    // property on this instance (which may itself be a prototype).
    const owner = typeof el === 'function' && el.prototype || el;
    if (!Object.hasOwnProperty.call(owner, 'hcEvents')) {
        owner.hcEvents = {};
    }
    const events = owner.hcEvents;
    // Allow click events added to points, otherwise they will be prevented by
    // the TouchPointer.pinch function after a pinch zoom operation (#7091).
    if ((highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default()).Point && // Without H a dependency loop occurs
        el instanceof (highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default()).Point &&
        el.series &&
        el.series.chart) {
        el.series.chart.runTrackerClick = true;
    }
    // Handle DOM events
    // If the browser supports passive events, add it to improve performance
    // on touch events (#11353).
    const addEventListener = el.addEventListener;
    if (addEventListener) {
        addEventListener.call(el, type, fn, (highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default()).supportsPassiveEvents ? {
            passive: options.passive === void 0 ?
                type.indexOf('touch') !== -1 : options.passive,
            capture: false
        } : false);
    }
    if (!events[type]) {
        events[type] = [];
    }
    const eventObject = {
        fn,
        order: typeof options.order === 'number' ? options.order : Infinity
    };
    events[type].push(eventObject);
    // Order the calls
    events[type].sort((a, b) => a.order - b.order);
    // Return a function that can be called to remove this event.
    return function () {
        removeEvent(el, type, fn);
    };
}
/**
 * Non-recursive method to find the lowest member of an array. `Math.min` raises
 * a maximum call stack size exceeded error in Chrome when trying to apply more
 * than 150.000 points. This method is slightly slower, but safe.
 *
 * @function Highcharts.arrayMin
 *
 * @param {Array<*>} data
 *        An array of numbers.
 *
 * @return {number}
 *         The lowest number.
 */
function arrayMin(data) {
    let i = data.length, min = data[0];
    while (i--) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    return min;
}
/**
 * Non-recursive method to find the lowest member of an array. `Math.max` raises
 * a maximum call stack size exceeded error in Chrome when trying to apply more
 * than 150.000 points. This method is slightly slower, but safe.
 *
 * @function Highcharts.arrayMax
 *
 * @param {Array<*>} data
 *        An array of numbers.
 *
 * @return {number}
 *         The highest number.
 */
function arrayMax(data) {
    let i = data.length, max = data[0];
    while (i--) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    return max;
}
/**
 * Set or get an attribute or an object of attributes.
 *
 * To use as a setter, pass a key and a value, or let the second argument be a
 * collection of keys and values. When using a collection, passing a value of
 * `null` or `undefined` will remove the attribute.
 *
 * To use as a getter, pass only a string as the second argument.
 *
 * @function Highcharts.attr
 *
 * @param {Highcharts.HTMLDOMElement|Highcharts.SVGDOMElement} elem
 *        The DOM element to receive the attribute(s).
 *
 * @param {string|Highcharts.HTMLAttributes|Highcharts.SVGAttributes} [keyOrAttribs]
 *        The property or an object of key-value pairs.
 *
 * @param {number|string} [value]
 *        The value if a single property is set.
 *
 * @return {string|null|undefined}
 *         When used as a getter, return the value.
 */
function attr(elem, keyOrAttribs, value) {
    const isGetter = isString(keyOrAttribs) && !defined(value);
    let ret;
    const attrSingle = (value, key) => {
        // Set the value
        if (defined(value)) {
            elem.setAttribute(key, value);
            // Get the value
        }
        else if (isGetter) {
            ret = elem.getAttribute(key);
            // IE7 and below cannot get class through getAttribute (#7850)
            if (!ret && key === 'class') {
                ret = elem.getAttribute(key + 'Name');
            }
            // Remove the value
        }
        else {
            elem.removeAttribute(key);
        }
    };
    // If keyOrAttribs is a string
    if (isString(keyOrAttribs)) {
        attrSingle(value, keyOrAttribs);
        // Else if keyOrAttribs is defined, it is a hash of key/value pairs
    }
    else {
        objectEach(keyOrAttribs, attrSingle);
    }
    return ret;
}
/**
 * Constrain a value to within a lower and upper threshold.
 *
 * @internal
 * @param {number} value The initial value
 * @param {number} min The lower threshold
 * @param {number} max The upper threshold
 * @return {number} Returns a number value within min and max.
 */
function clamp(value, min, max) {
    return value > min ? value < max ? value : max : min;
}
/**
 * Fix JS round off float errors.
 *
 * @function Highcharts.correctFloat
 *
 * @param {number} num
 *        A float number to fix.
 *
 * @param {number} [prec=14]
 *        The precision.
 *
 * @return {number}
 *         The corrected float number.
 */
function correctFloat(num, prec) {
    // When the number is higher than 1e14 use the number (#16275)
    return num > 1e14 ? num : parseFloat(num.toPrecision(prec || 14));
}
/**
 * Utility function to create an HTML element with attributes and styles.
 *
 * @function Highcharts.createElement
 *
 * @param {string} tag
 *        The HTML tag.
 *
 * @param {Highcharts.HTMLAttributes} [attribs]
 *        Attributes as an object of key-value pairs.
 *
 * @param {Highcharts.CSSObject} [styles]
 *        Styles as an object of key-value pairs.
 *
 * @param {Highcharts.HTMLDOMElement} [parent]
 *        The parent HTML object.
 *
 * @param {boolean} [nopad=false]
 *        If true, remove all padding, border and margin.
 *
 * @return {Highcharts.HTMLDOMElement}
 *         The created DOM element.
 */
function createElement(tag, attribs, styles, parent, nopad) {
    const el = doc.createElement(tag);
    if (attribs) {
        extend(el, attribs);
    }
    if (nopad) {
        css(el, { padding: '0', border: 'none', margin: '0' });
    }
    if (styles) {
        css(el, styles);
    }
    if (parent) {
        parent.appendChild(el);
    }
    return el;
}
/**
 * Utility for crisping a line position to the nearest full pixel depending on
 * the line width.
 *
 * @internal
 * @param {number} value       The raw pixel position
 * @param {number} lineWidth   The line width
 * @param {boolean} [inverted] Whether the containing group is inverted.
 *                             Crisping round numbers on the y-scale need to go
 *                             to the other side because the coordinate system
 *                             is flipped (scaleY is -1)
 * @return {number}            The pixel position to use for a crisp display
 */
function crisp(value, lineWidth = 0, inverted) {
    const mod = lineWidth % 2 / 2, inverter = inverted ? -1 : 1;
    return (Math.round(value * inverter - mod) + mod) * inverter;
}
/**
 * Set CSS on a given element.
 *
 * @function Highcharts.css
 *
 * @param {Highcharts.HTMLDOMElement|Highcharts.SVGDOMElement} el
 *        An HTML DOM element.
 *
 * @param {Highcharts.CSSObject} styles
 *        Style object with camel case property names.
 *
 * @return {void}
 */
function css(el, styles) {
    extend(el.style, styles);
}
/**
 * Check if an object is null or undefined.
 *
 * @function Highcharts.defined
 *
 * @param {*} obj
 *        The object to check.
 *
 * @return {boolean}
 *         False if the object is null or undefined, otherwise true.
 */
function defined(obj) {
    return typeof obj !== 'undefined' && obj !== null;
}
/**
 * Utility method that destroys any SVGElement instances that are properties on
 * the given object. It loops all properties and invokes destroy if there is a
 * destroy method. The property is then delete.
 *
 * @function Highcharts.destroyObjectProperties
 *
 * @param {*} obj
 *        The object to destroy properties on.
 *
 * @param {*} [except]
 *        Exception, do not destroy this property, only delete it.
 */
function destroyObjectProperties(obj, except, destructablesOnly) {
    objectEach(obj, function (val, n) {
        // If the object is non-null and destroy is defined
        if (val !== except && val?.destroy) {
            // Invoke the destroy
            val.destroy();
        }
        // Delete the property from the object
        if (val?.destroy || !destructablesOnly) {
            delete obj[n];
        }
    });
}
/**
 * Discard a HTML element
 *
 * @function Highcharts.discardElement
 *
 * @param {Highcharts.HTMLDOMElement} element
 *        The HTML node to discard.
 */
function discardElement(element) {
    element?.parentElement?.removeChild(element);
}
// eslint-disable-next-line valid-jsdoc
/**
 * Return the deep difference between two objects. It can either return the new
 * properties, or optionally return the old values of new properties.
 * @internal
 */
function diffObjects(newer, older, keepOlder, collectionsWithUpdate) {
    const ret = {};
    /**
     * Recurse over a set of options and its current values, and store the
     * current values in the ret object.
     */
    function diff(newer, older, ret, depth) {
        const keeper = keepOlder ? older : newer;
        objectEach(newer, function (newerVal, key) {
            if (!depth &&
                collectionsWithUpdate &&
                collectionsWithUpdate.indexOf(key) > -1 &&
                older[key]) {
                newerVal = splat(newerVal);
                ret[key] = [];
                // Iterate over collections like series, xAxis or yAxis and map
                // the items by index.
                for (let i = 0; i < Math.max(newerVal.length, older[key].length); i++) {
                    // Item exists in current data (#6347)
                    if (older[key][i]) {
                        // If the item is missing from the new data, we need to
                        // save the whole config structure. Like when
                        // responsively updating from a dual axis layout to a
                        // single axis and back (#13544).
                        if (newerVal[i] === void 0) {
                            ret[key][i] = older[key][i];
                            // Otherwise, proceed
                        }
                        else {
                            ret[key][i] = {};
                            diff(newerVal[i], older[key][i], ret[key][i], depth + 1);
                        }
                    }
                }
            }
            else if (isObject(newerVal, true) &&
                !newerVal.nodeType // #10044
            ) {
                ret[key] = isArray(newerVal) ? [] : {};
                diff(newerVal, older[key] || {}, ret[key], depth + 1);
                // Delete empty nested objects
                if (Object.keys(ret[key]).length === 0 &&
                    // Except colorAxis which is a special case where the empty
                    // object means it is enabled. Which is unfortunate and we
                    // should try to find a better way.
                    !(key === 'colorAxis' && depth === 0)) {
                    delete ret[key];
                }
            }
            else if (newer[key] !== older[key] ||
                // If the newer key is explicitly undefined, keep it (#10525)
                (key in newer && !(key in older))) {
                if (key !== '__proto__' && key !== 'constructor') {
                    ret[key] = keeper[key];
                }
            }
        });
    }
    diff(newer, older, ret, 0);
    return ret;
}
/**
 * Remove the last occurrence of an item from an array.
 *
 * @function Highcharts.erase
 *
 * @param {Array<*>} arr
 *        The array.
 *
 * @param {*} item
 *        The item to remove.
 *
 * @return {void}
 */
function erase(arr, item) {
    let i = arr.length;
    while (i--) {
        if (arr[i] === item) {
            arr.splice(i, 1);
            break;
        }
    }
}
/**
 * Utility function to extend an object with the members of another.
 *
 * @function Highcharts.extend<T>
 *
 * @param {T|undefined} a
 *        The object to be extended.
 *
 * @param {Partial<T>} b
 *        The object to add to the first one.
 *
 * @return {T}
 *         Object a, the original object.
 */
function extend(a, b) {
    let n;
    if (!a) {
        a = {};
    }
    for (n in b) { // eslint-disable-line guard-for-in
        a[n] = b[n];
    }
    return a;
}
// eslint-disable-next-line valid-jsdoc
/**
 * Extend a prototyped class by new members.
 *
 * @deprecated
 * @function Highcharts.extendClass<T>
 *
 * @param {Highcharts.Class<T>} parent
 *        The parent prototype to inherit.
 *
 * @param {Highcharts.Dictionary<*>} members
 *        A collection of prototype members to add or override compared to the
 *        parent prototype.
 *
 * @return {Highcharts.Class<T>}
 *         A new prototype.
 */
function extendClass(parent, members) {
    const obj = (function () { });
    obj.prototype = new parent(); // eslint-disable-line new-cap
    extend(obj.prototype, members);
    return obj;
}
/**
 * Fire an event that was registered with {@link Highcharts#addEvent}.
 *
 * @function Highcharts.fireEvent<T>
 *
 * @param {T} el
 *        The object to fire the event on. It can be a {@link HTMLDOMElement},
 *        an {@link SVGElement} or any other object.
 *
 * @param {string} type
 *        The type of event.
 *
 * @param {Highcharts.Dictionary<*>|Event} [eventArguments]
 *        Custom event arguments that are passed on as an argument to the event
 *        handler.
 *
 * @param {Highcharts.EventCallbackFunction<T>|Function} [defaultFunction]
 *        The default function to execute if the other listeners haven't
 *        returned false.
 *
 * @return {void}
 */
function fireEvent(el, type, eventArguments, defaultFunction) {
    eventArguments = eventArguments || {};
    if (doc?.createEvent &&
        (el.dispatchEvent ||
            (el.fireEvent &&
                // Enable firing events on Highcharts instance.
                el !== H))) {
        const e = doc.createEvent('Events');
        e.initEvent(type, true, true);
        eventArguments = extend(e, eventArguments);
        if (el.dispatchEvent) {
            el.dispatchEvent(eventArguments);
        }
        else {
            el.fireEvent(type, eventArguments);
        }
    }
    else if (el.hcEvents) {
        if (!eventArguments.target) {
            // We're running a custom event
            extend(eventArguments, {
                // Attach a simple preventDefault function to skip
                // default handler if called. The built-in
                // defaultPrevented property is not overwritable (#5112)
                preventDefault: function () {
                    eventArguments.defaultPrevented = true;
                },
                // Setting target to native events fails with clicking
                // the zoom-out button in Chrome.
                target: el,
                // If the type is not set, we're running a custom event
                // (#2297). If it is set, we're running a browser event.
                type: type
            });
        }
        const events = [];
        let object = el;
        let multilevel = false;
        // Recurse up the inheritance chain and collect hcEvents set as own
        // objects on the prototypes.
        while (object.hcEvents) {
            if (Object.hasOwnProperty.call(object, 'hcEvents') &&
                object.hcEvents[type]) {
                if (events.length) {
                    multilevel = true;
                }
                events.unshift.apply(events, object.hcEvents[type]);
            }
            object = Object.getPrototypeOf(object);
        }
        // For performance reasons, only sort the event handlers in case we are
        // dealing with multiple levels in the prototype chain. Otherwise, the
        // events are already sorted in the addEvent function.
        if (multilevel) {
            // Order the calls
            events.sort((a, b) => a.order - b.order);
        }
        // Call the collected event handlers
        events.forEach((obj) => {
            // If the event handler returns false, prevent the default handler
            // from executing
            if (obj.fn.call(el, eventArguments, el) === false) {
                eventArguments.preventDefault();
            }
        });
    }
    // Run the default if not prevented
    if (defaultFunction && !eventArguments.defaultPrevented) {
        defaultFunction.call(el, eventArguments);
    }
}
/**
 * Convenience function to get the align factor, used several places for
 * computing positions
 * @internal
 */
const getAlignFactor = (align = '') => ({
    center: 0.5,
    right: 1,
    middle: 0.5,
    bottom: 1
}[align] || 0);
/**
 * Find the closest distance between two values of a two-dimensional array
 * @internal
 * @function Highcharts.getClosestDistance
 *
 * @param {Array<Array<number>>} arrays
 *          An array of arrays of numbers
 *
 * @return {number | undefined}
 *          The closest distance between values
 */
function getClosestDistance(arrays, onError) {
    const allowNegative = !onError;
    let closest, loopLength, distance, i;
    arrays.forEach((xData) => {
        if (xData.length > 1) {
            loopLength = xData.length - 1;
            for (i = loopLength; i > 0; i--) {
                distance = xData[i] - xData[i - 1];
                if (distance < 0 && !allowNegative) {
                    onError?.();
                    // Only one call
                    onError = void 0;
                }
                else if (distance && (typeof closest === 'undefined' || distance < closest)) {
                    closest = distance;
                }
            }
        }
    });
    return closest;
}
/**
 * Get the magnitude of a number.
 *
 * @function Highcharts.getMagnitude
 *
 * @param {number} num
 *        The number.
 *
 * @return {number}
 *         The magnitude, where 1-9 are magnitude 1, 10-99 magnitude 2 etc.
 */
function getMagnitude(num) {
    return Math.pow(10, Math.floor(Math.log(num) / Math.LN10));
}
/**
 * Returns the value of a property path on a given object.
 *
 * @internal
 * @function getNestedProperty
 *
 * @param {string} path
 * Path to the property, for example `custom.myValue`.
 *
 * @param {unknown} parent
 * Instance containing the property on the specific path.
 *
 * @return {unknown}
 * The unknown property value.
 */
function getNestedProperty(path, parent) {
    const pathElements = path.split('.');
    while (pathElements.length && defined(parent)) {
        const pathElement = pathElements.shift();
        // Filter on the key
        if (typeof pathElement === 'undefined' ||
            pathElement === '__proto__') {
            return; // Undefined
        }
        if (pathElement === 'this') {
            let thisProp;
            if (isObject(parent)) {
                thisProp = parent['@this'];
            }
            return thisProp ?? parent;
        }
        const child = parent[pathElement.replace(/[\\'"]/g, '')];
        // Filter on the child
        if (!defined(child) ||
            typeof child === 'function' ||
            typeof child.nodeType === 'number' ||
            child === win) {
            return; // Undefined
        }
        // Else, proceed
        parent = child;
    }
    return parent;
}
/**
 * Get the computed CSS value for given element and property, only for numerical
 * properties. For width and height, the dimension of the inner box (excluding
 * padding) is returned. Used for fitting the chart within the container.
 *
 * @function Highcharts.getStyle
 *
 * @param {Highcharts.HTMLDOMElement} el
 * An HTML element.
 *
 * @param {string} prop
 * The property name.
 *
 * @param {boolean} [toInt=true]
 * Parse to integer.
 *
 * @return {number|string|undefined}
 * The style value.
 */
function getStyle(el, prop, toInt) {
    let style;
    // For width and height, return the actual inner pixel size (#4913)
    if (prop === 'width') {
        let offsetWidth = Math.min(el.offsetWidth, el.scrollWidth);
        // In flex boxes, we need to use getBoundingClientRect and floor it,
        // because scrollWidth doesn't support subpixel precision (#6427) ...
        const boundingClientRectWidth = el.getBoundingClientRect?.().width;
        // ...unless if the containing div or its parents are transform-scaled
        // down, in which case the boundingClientRect can't be used as it is
        // also scaled down (#9871, #10498).
        if (boundingClientRectWidth < offsetWidth &&
            boundingClientRectWidth >= offsetWidth - 1) {
            offsetWidth = Math.floor(boundingClientRectWidth);
        }
        return Math.max(0, // #8377
        (offsetWidth -
            (getStyle(el, 'padding-left', true) || 0) -
            (getStyle(el, 'padding-right', true) || 0)));
    }
    if (prop === 'height') {
        return Math.max(0, // #8377
        (Math.min(el.offsetHeight, el.scrollHeight) -
            (getStyle(el, 'padding-top', true) || 0) -
            (getStyle(el, 'padding-bottom', true) || 0)));
    }
    // Otherwise, get the computed style
    const css = win.getComputedStyle(el, void 0); // eslint-disable-line no-undefined
    if (css) {
        style = css.getPropertyValue(prop);
        if (pick(toInt, prop !== 'opacity')) {
            style = pInt(style);
        }
    }
    return style;
}
/**
 * Return the value of the first element in the array that satisfies the
 * provided testing function.
 *
 * @function Highcharts.find<T>
 *
 * @param {Array<T>} arr
 *        The array to test.
 *
 * @param {Function} callback
 *        The callback function. The function receives the item as the first
 *        argument. Return `true` if this item satisfies the condition.
 *
 * @return {T|undefined}
 *         The value of the element.
 */
const find = Array.prototype.find ?
    function (arr, callback) {
        return arr.find(callback);
    } :
    // Legacy implementation. PhantomJS, IE <= 11 etc. #7223.
    function (arr, callback) {
        let i;
        const length = arr.length;
        for (i = 0; i < length; i++) {
            if (callback(arr[i], i)) { // eslint-disable-line node/callback-return
                return arr[i];
            }
        }
    };
/**
 * Internal clear timeout. The function checks that the `id` was not removed
 * (e.g. by `chart.destroy()`). For the details see
 * [issue #7901](https://github.com/highcharts/highcharts/issues/7901).
 *
 * @internal
 *
 * @function Highcharts.clearTimeout
 *
 * @param {number|undefined} id
 * Id of a timeout.
 */
function internalClearTimeout(id) {
    if (defined(id)) {
        clearTimeout(id);
    }
}
/**
 * Utility function to check if an Object is a HTML Element.
 *
 * @function Highcharts.isDOMElement
 *
 * @param {*} obj
 *        The item to check.
 *
 * @return {boolean}
 *         True if the argument is a HTML Element.
 */
function isDOMElement(obj) {
    return isObject(obj) && typeof obj.nodeType === 'number';
}
/**
 * Utility function to check if an Object is a class.
 *
 * @function Highcharts.isClass
 *
 * @param {object|undefined} obj
 *        The item to check.
 *
 * @return {boolean}
 *         True if the argument is a class.
 */
function isClass(obj) {
    const c = obj?.constructor;
    return !!(isObject(obj, true) &&
        !isDOMElement(obj) &&
        (c?.name && c.name !== 'Object'));
}
/**
 * Utility function to check if an item is a number and it is finite (not NaN,
 * Infinity or -Infinity).
 *
 * @function Highcharts.isNumber
 *
 * @param {*} n
 *        The item to check.
 *
 * @return {boolean}
 *         True if the item is a finite number
 */
function isNumber(n) {
    return typeof n === 'number' && !isNaN(n) && n < Infinity && n > -Infinity;
}
/**
 * Utility function to check for string type.
 *
 * @function Highcharts.isString
 *
 * @param {*} s
 *        The item to check.
 *
 * @return {boolean}
 *         True if the argument is a string.
 */
function isString(s) {
    return typeof s === 'string';
}
/**
 * Utility function to check if an item is an array.
 *
 * @function Highcharts.isArray
 *
 * @param {*} obj
 *        The item to check.
 *
 * @return {boolean}
 *         True if the argument is an array.
 */
function isArray(obj) {
    const str = Object.prototype.toString.call(obj);
    return str === '[object Array]' || str === '[object Array Iterator]';
}
/**
 * Utility function to check if object is a function.
 *
 * @function Highcharts.isFunction
 *
 * @param {*} obj
 *        The item to check.
 *
 * @return {boolean}
 *         True if the argument is a function.
 */
function isFunction(obj) {
    return typeof obj === 'function';
}
/**
 * Utility function to check if an item is of type object.
 *
 * @function Highcharts.isObject
 *
 * @param {*} obj
 *        The item to check.
 *
 * @param {boolean} [strict=false]
 *        Also checks that the object is not an array.
 *
 * @return {boolean}
 *         True if the argument is an object.
 */
function isObject(obj, strict) {
    return (!!obj &&
        typeof obj === 'object' &&
        (!strict || !isArray(obj))); // eslint-disable-line @typescript-eslint/no-explicit-any
}
/**
 * Utility function to deep merge two or more objects and return a third object.
 * If the first argument is true, the contents of the second object is copied
 * into the first object. The merge function can also be used with a single
 * object argument to create a deep copy of an object.
 *
 * @function Highcharts.merge<T>
 *
 * @param {true | T} extendOrSource
 *        Whether to extend the left-side object,
 *        or the first object to merge as a deep copy.
 *
 * @param {...Array<object|undefined>} [sources]
 *        Object(s) to merge into the previous one.
 *
 * @return {T}
 *         The merged object. If the first argument is true, the return is the
 *         same as the second argument.
 */
function merge(extendOrSource, ...sources) {
    let i, args = [extendOrSource, ...sources], ret = {};
    const doCopy = function (copy, original) {
        // An object is replacing a primitive
        if (typeof copy !== 'object') {
            copy = {};
        }
        objectEach(original, function (value, key) {
            // Prototype pollution (#14883)
            if (key === '__proto__' || key === 'constructor') {
                return;
            }
            // Copy the contents of objects, but not arrays or DOM nodes
            if (isObject(value, true) &&
                !isClass(value) &&
                !isDOMElement(value)) {
                copy[key] = doCopy(copy[key] || {}, value);
                // Primitives and arrays are copied over directly
            }
            else {
                copy[key] = original[key];
            }
        });
        return copy;
    };
    // If first argument is true, copy into the existing object. Used in
    // setOptions.
    if (extendOrSource === true) {
        ret = args[1];
        args = Array.prototype.slice.call(args, 2);
    }
    // For each argument, extend the return
    const len = args.length;
    for (i = 0; i < len; i++) {
        ret = doCopy(ret, args[i]);
    }
    return ret;
}
/**
 * Take an interval and normalize it to multiples of round numbers.
 *
 * @deprecated
 * @function Highcharts.normalizeTickInterval
 *
 * @param {number} interval
 *        The raw, un-rounded interval.
 *
 * @param {Array<*>} [multiples]
 *        Allowed multiples.
 *
 * @param {number} [magnitude]
 *        The magnitude of the number.
 *
 * @param {boolean} [allowDecimals]
 *        Whether to allow decimals.
 *
 * @param {boolean} [hasTickAmount]
 *        If it has tickAmount, avoid landing on tick intervals lower than
 *        original.
 *
 * @return {number}
 *         The normalized interval.
 *
 * @todo
 * Move this function to the Axis prototype. It is here only for historical
 * reasons.
 */
function normalizeTickInterval(interval, multiples, magnitude, allowDecimals, hasTickAmount) {
    let i, retInterval = interval;
    // Round to a tenfold of 1, 2, 2.5 or 5
    magnitude = pick(magnitude, getMagnitude(interval));
    const normalized = interval / magnitude;
    // Multiples for a linear scale
    if (!multiples) {
        multiples = hasTickAmount ?
            // Finer grained ticks when the tick amount is hard set, including
            // when alignTicks is true on multiple axes (#4580).
            [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10] :
            // Else, let ticks fall on rounder numbers
            [1, 2, 2.5, 5, 10];
        // The allowDecimals option
        if (allowDecimals === false) {
            if (magnitude === 1) {
                multiples = multiples.filter(function (num) {
                    return num % 1 === 0;
                });
            }
            else if (magnitude <= 0.1) {
                multiples = [1 / magnitude];
            }
        }
    }
    // Normalize the interval to the nearest multiple
    for (i = 0; i < multiples.length; i++) {
        retInterval = multiples[i];
        // Only allow tick amounts smaller than natural
        if ((hasTickAmount &&
            retInterval * magnitude >= interval) ||
            (!hasTickAmount &&
                (normalized <=
                    (multiples[i] +
                        (multiples[i + 1] || multiples[i])) / 2))) {
            break;
        }
    }
    // Multiply back to the correct magnitude. Correct floats to appropriate
    // precision (#6085).
    retInterval = correctFloat(retInterval * magnitude, -Math.round(Math.log(0.001) / Math.LN10));
    return retInterval;
}
/**
 * Iterate over object key pairs in an object.
 *
 * @function Highcharts.objectEach<T>
 *
 * @param {*} obj
 *        The object to iterate over.
 *
 * @param {Highcharts.ObjectEachCallbackFunction<T>} fn
 *        The iterator callback. It passes three arguments:
 *        * value - The property value.
 *        * key - The property key.
 *        * obj - The object that objectEach is being applied to.
 *
 * @param {T} [ctx]
 *        The context.
 */
function objectEach(obj, fn, ctx) {
    for (const key in obj) {
        if (Object.hasOwnProperty.call(obj, key)) {
            fn.call(ctx || obj[key], obj[key], key, obj);
        }
    }
}
/**
 * Get the element's offset position, corrected for `overflow: auto`.
 *
 * @function Highcharts.offset
 *
 * @param {global.Element} el
 *        The DOM element.
 *
 * @return {Highcharts.OffsetObject}
 *         An object containing `left` and `top` properties for the position in
 *         the page.
 */
function offset(el) {
    const docElem = doc.documentElement, box = (el.parentElement || el.parentNode) ?
        el.getBoundingClientRect() :
        { top: 0, left: 0, width: 0, height: 0 };
    return {
        top: box.top + (win.pageYOffset || docElem.scrollTop) -
            (docElem.clientTop || 0),
        left: box.left + (win.pageXOffset || docElem.scrollLeft) -
            (docElem.clientLeft || 0),
        width: box.width,
        height: box.height
    };
}
/**
 * Left-pad a string to a given length by adding a character repetitively.
 *
 * @function Highcharts.pad
 *
 * @param {number} number
 *        The input string or number.
 *
 * @param {number} [length]
 *        The desired string length.
 *
 * @param {string} [padder=0]
 *        The character to pad with.
 *
 * @return {string}
 *         The padded string.
 */
function pad(number, length, padder) {
    return new Array((length || 2) +
        1 -
        String(number)
            .replace('-', '')
            .length).join(padder || '0') + number;
}
/* eslint-disable jsdoc/check-param-names */
/**
 * Return the first value that is not null or undefined.
 *
 * @function Highcharts.pick<T>
 *
 * @param {...Array<T|null|undefined>} items
 *        Variable number of arguments to inspect.
 *
 * @return {T}
 *         The value of the first argument that is not null or undefined.
 */
function pick() {
    const args = arguments;
    const length = args.length;
    for (let i = 0; i < length; i++) {
        const arg = args[i];
        if (typeof arg !== 'undefined' && arg !== null) {
            return arg;
        }
    }
}
/* eslint-enable jsdoc/check-param-names */
/**
 * Shortcut for parseInt
 *
 * @internal
 * @function Highcharts.pInt
 *
 * @param {*} s
 *        any
 *
 * @param {number} [mag]
 *        Magnitude
 *
 * @return {number}
 *         number
 */
function pInt(s, mag) {
    return parseInt(s, mag || 10);
}
/**
 * Adds an item to an array, if it is not present in the array.
 *
 * @internal
 *
 * @function Highcharts.pushUnique
 *
 * @param {Array<unknown>} array
 * The array to add the item to.
 *
 * @param {unknown} item
 * The item to add.
 *
 * @return {boolean}
 * Returns true, if the item was not present and has been added.
 */
function pushUnique(array, item) {
    return array.indexOf(item) < 0 && !!array.push(item);
}
/**
 * Return a length based on either the integer value, or a percentage of a base.
 *
 * @function Highcharts.relativeLength
 *
 * @param {Highcharts.RelativeSize} value
 *        A percentage string or a number.
 *
 * @param {number} base
 *        The full length that represents 100%.
 *
 * @param {number} [offset=0]
 *        A pixel offset to apply for percentage values. Used internally in
 *        axis positioning.
 *
 * @return {number}
 *         The computed length.
 */
function relativeLength(value, base, offset) {
    return (/%$/).test(value) ?
        (base * parseFloat(value) / 100) + (offset || 0) :
        parseFloat(value);
}
/**
 * Replaces text in a string with a given replacement in a loop to catch nested
 * matches after previous replacements.
 *
 * @internal
 *
 * @function Highcharts.replaceNested
 *
 * @param {string} text
 * Text to search and modify.
 *
 * @param {...Array<(RegExp|string)>} replacements
 * One or multiple tuples with search pattern (`[0]: (string|RegExp)`) and
 * replacement (`[1]: string`) for matching text.
 *
 * @return {string}
 * Text with replacements.
 */
function replaceNested(text, ...replacements) {
    let previous, replacement;
    do {
        previous = text;
        for (replacement of replacements) {
            text = text.replace(replacement[0], replacement[1]);
        }
    } while (text !== previous);
    return text;
}
/**
 * Remove an event that was added with {@link Highcharts#addEvent}.
 *
 * @function Highcharts.removeEvent<T>
 *
 * @param {Highcharts.Class<T>|T} el
 *        The element to remove events on.
 *
 * @param {string} [type]
 *        The type of events to remove. If undefined, all events are removed
 *        from the element.
 *
 * @param {Highcharts.EventCallbackFunction<T>} [fn]
 *        The specific callback to remove. If undefined, all events that match
 *        the element and optionally the type are removed.
 *
 * @return {void}
 */
function removeEvent(el, type, fn) {
    /** @internal */
    function removeOneEvent(type, fn) {
        const removeEventListener = el.removeEventListener;
        if (removeEventListener) {
            removeEventListener.call(el, type, fn, false);
        }
    }
    /** @internal */
    function removeAllEvents(eventCollection) {
        let types, len;
        if (!el.nodeName) {
            return; // Break on non-DOM events
        }
        if (type) {
            types = {};
            types[type] = true;
        }
        else {
            types = eventCollection;
        }
        objectEach(types, function (_val, n) {
            if (eventCollection[n]) {
                len = eventCollection[n].length;
                while (len--) {
                    removeOneEvent(n, eventCollection[n][len].fn);
                }
            }
        });
    }
    const owner = typeof el === 'function' && el.prototype || el;
    if (Object.hasOwnProperty.call(owner, 'hcEvents')) {
        const events = owner.hcEvents;
        if (type) {
            const typeEvents = (events[type] || []);
            if (fn) {
                events[type] = typeEvents.filter(function (obj) {
                    return fn !== obj.fn;
                });
                removeOneEvent(type, fn);
            }
            else {
                removeAllEvents(events);
                events[type] = [];
            }
        }
        else {
            removeAllEvents(events);
            delete owner.hcEvents;
        }
    }
}
/**
 * Check if an element is an array, and if not, make it into an array.
 *
 * @function Highcharts.splat
 *
 * @param {*} obj
 *        The object to splat.
 *
 * @return {Array}
 *         The produced or original array.
 */
function splat(obj) {
    return isArray(obj) ? obj : [obj];
}
/**
 * Sort an object array and keep the order of equal items. The ECMAScript
 * standard does not specify the behavior when items are equal.
 *
 * @function Highcharts.stableSort
 *
 * @param {Array<*>} arr
 *        The array to sort.
 *
 * @param {Function} sortFunction
 *        The function to sort it with, like with regular Array.prototype.sort.
 */
function stableSort(arr, sortFunction) {
    // @todo It seems like Chrome since v70 sorts in a stable way internally,
    // plus all other browsers do it, so over time we may be able to remove this
    // function
    const length = arr.length;
    let sortValue, i;
    // Add index to each item
    for (i = 0; i < length; i++) {
        arr[i].safeI = i; // Stable sort index
    }
    arr.sort(function (a, b) {
        sortValue = sortFunction(a, b);
        return sortValue === 0 ? a.safeI - b.safeI : sortValue;
    });
    // Remove index from items
    for (i = 0; i < length; i++) {
        delete arr[i].safeI; // Stable sort index
    }
}
/**
 * Set a timeout if the delay is given, otherwise perform the function
 * synchronously.
 *
 * @function Highcharts.syncTimeout
 *
 * @param {Function} fn
 *        The function callback.
 *
 * @param {number} delay
 *        Delay in milliseconds.
 *
 * @param {*} [context]
 *        An optional context to send to the function callback.
 *
 * @return {number}
 *         An identifier for the timeout that can later be cleared with
 *         Highcharts.clearTimeout. Returns -1 if there is no timeout.
 */
function syncTimeout(fn, delay, context) {
    if (delay > 0) {
        return setTimeout(fn, delay, context);
    }
    fn.call(0, context);
    return -1;
}
/**
 * @internal
 */
function ucfirst(s) {
    return ((isString(s) ?
        s.substring(0, 1).toUpperCase() + s.substring(1) :
        String(s)));
}
/**
 * Wrap a method with extended functionality, preserving the original function.
 *
 * @function Highcharts.wrap
 *
 * @param {*} obj
 *        The context object that the method belongs to. In real cases, this is
 *        often a prototype.
 *
 * @param {string} method
 *        The name of the method to extend.
 *
 * @param {Highcharts.WrapProceedFunction} func
 *        A wrapper function callback. This function is called with the same
 *        arguments as the original function, except that the original function
 *        is unshifted and passed as the first argument.
 */
function wrap(obj, method, func) {
    const proceed = obj[method];
    obj[method] = function () {
        const outerArgs = arguments, scope = this;
        return func.apply(this, [
            function () {
                return proceed.apply(scope, arguments.length ? arguments : outerArgs);
            }
        ].concat([].slice.call(arguments)));
    };
}

;// ./code/es-modules/Extensions/Themes/Adaptive.js
/* *
 *
 *   (c) 2010-2026 Highsoft AS
 *
 *  Author: Torstein Hønsi
 *
 *  Integration of this software requires a license.
 *  - For commercial use, see www.highcharts.com/license
 *  - For non-commercial, see www.highcharts.com/license-eula
 *
 *  Dynamic light/dark theme based on CSS variables
 *
 *
 * */




const { setOptions } = (highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default());
/* *
 *
 *  Theme
 *
 * */
/**
 * The color variable names and values are copied from highcharts.css
 */
const defaultRules = `
        /* Colors for data series and points */
        --highcharts-color-0: #2caffe;
        --highcharts-color-1: #544fc5;
        --highcharts-color-2: #00e272;
        --highcharts-color-3: #fe6a35;
        --highcharts-color-4: #6b8abc;
        --highcharts-color-5: #d568fb;
        --highcharts-color-6: #2ee0ca;
        --highcharts-color-7: #fa4b42;
        --highcharts-color-8: #feb56a;
        --highcharts-color-9: #91e8e1;

    /* Chart background, point stroke for markers and columns etc */
    --highcharts-background-color: #ffffff;

    /*
    Neutral colors, grayscale by default. The default colors are defined by
    mixing the background-color with neutral, with a weight corresponding to
    the number in the name.

    https://www.highcharts.com/samples/highcharts/css/palette-helper
    */

    /* Strong text. */
    --highcharts-neutral-color-100: #000000;

    /* Main text, axis labels and some strokes. */
    --highcharts-neutral-color-80: #333333;

    /* Axis title, connector fallback. */
    --highcharts-neutral-color-60: #666666;

    /* Credits text, export menu stroke. */
    --highcharts-neutral-color-40: #999999;

    /* Disabled texts, button strokes, crosshair etc. */
    --highcharts-neutral-color-20: #cccccc;

    /* Grid lines etc. */
    --highcharts-neutral-color-10: #e6e6e6;

    /* Minor grid lines etc. */
    --highcharts-neutral-color-5: #f2f2f2;

    /* Tooltip background, button fills, map null points. */
    --highcharts-neutral-color-3: #f7f7f7;

    /*
    Highlights, shades of blue by default
    */

    /* Drilldown clickable labels, color axis max color. */
    --highcharts-highlight-color-100: #0022ff;

    /* Selection marker, menu hover, button hover, chart border, navigator
    series. */
    --highcharts-highlight-color-80: #334eff;

    /* Navigator mask fill. */
    --highcharts-highlight-color-60: #667aff;

    /* Ticks and axis line. */
    --highcharts-highlight-color-20: #ccd3ff;

    /* Pressed button, color axis min color. */
    --highcharts-highlight-color-10: #e6e9ff;

    /* Indicators */
    --highcharts-positive-color: #06b535;
    --highcharts-negative-color: #f21313;

    /* Transparent colors for annotations */
    --highcharts-annotation-color-0: rgba(130, 170, 255, 0.4);
    --highcharts-annotation-color-1: rgba(139, 191, 216, 0.4);
    --highcharts-annotation-color-2: rgba(150, 216, 192, 0.4);
    --highcharts-annotation-color-3: rgba(156, 229, 161, 0.4);
    --highcharts-annotation-color-4: rgba(162, 241, 130, 0.4);
    --highcharts-annotation-color-5: rgba(169, 255, 101, 0.4);
`;
const darkRules = `
    /* Colors for data series and points */
    --highcharts-color-1: #00e272;
    --highcharts-color-2: #efdf00;

    /* UI colors */
    --highcharts-background-color: #141414;

    /*
        Neutral color variations
        https://www.highcharts.com/samples/highcharts/css/palette-helper
    */
    --highcharts-neutral-color-100: #ffffff;
    --highcharts-neutral-color-80: #d0d0d0;
    --highcharts-neutral-color-60: #a1a1a1;
    --highcharts-neutral-color-40: #727272;
    --highcharts-neutral-color-20: #434343;
    --highcharts-neutral-color-10: #2c2c2c;
    --highcharts-neutral-color-5: #202020;
    --highcharts-neutral-color-3: #1b1b1b;

    /* Highlight color variations */
    --highcharts-highlight-color-100: #2caffe;
    --highcharts-highlight-color-80: #2790cf;
    --highcharts-highlight-color-60: #2271a0;
    --highcharts-highlight-color-20: #193343;
    --highcharts-highlight-color-10: #16242b;
`;
const styleSheet = `
:root,
.highcharts-light {
    ${defaultRules}
}

@media (prefers-color-scheme: dark) {
    :root {
        ${darkRules}
    }
}

.highcharts-dark {
    ${darkRules}
}

.highcharts-container {
    color-scheme: light dark;
}

.highcharts-light .highcharts-container {
    color-scheme: light;
}

.highcharts-dark .highcharts-container {
    color-scheme: dark;
}
`;
var DynamicDefaultTheme;
(function (DynamicDefaultTheme) {
    /* *
     *
     *  Constants
     *
     * */
    /**
     * The options are generated using the highcharts/css/palette-helper
     * sample
     */
    DynamicDefaultTheme.options = {
        colors: [
            'var(--highcharts-color-0)',
            'var(--highcharts-color-1)',
            'var(--highcharts-color-2)',
            'var(--highcharts-color-3)',
            'var(--highcharts-color-4)',
            'var(--highcharts-color-5)',
            'var(--highcharts-color-6)',
            'var(--highcharts-color-7)',
            'var(--highcharts-color-8)',
            'var(--highcharts-color-9)'
        ],
        global: {
            buttonTheme: {
                fill: 'var(--highcharts-neutral-color-3)',
                stroke: 'var(--highcharts-neutral-color-20)',
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                },
                states: {
                    hover: {
                        fill: 'var(--highcharts-neutral-color-10)'
                    },
                    select: {
                        fill: 'var(--highcharts-highlight-color-10)',
                        style: {
                            color: 'var(--highcharts-neutral-color-100)'
                        }
                    },
                    disabled: {
                        style: {
                            color: 'var(--highcharts-neutral-color-20)'
                        }
                    }
                }
            }
        },
        chart: {
            borderColor: 'var(--highcharts-highlight-color-80)',
            backgroundColor: 'var(--highcharts-background-color)',
            plotBorderColor: 'var(--highcharts-neutral-color-20)'
        },
        title: {
            style: {
                color: 'var(--highcharts-neutral-color-80)'
            }
        },
        subtitle: {
            style: {
                color: 'var(--highcharts-neutral-color-60)'
            }
        },
        caption: {
            style: {
                color: 'var(--highcharts-neutral-color-60)'
            }
        },
        plotOptions: {
            line: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            area: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            spline: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            areaspline: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            column: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            bar: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            scatter: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            pie: {
                borderColor: 'var(--highcharts-background-color)'
            },
            hlc: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            ohlc: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            candlestick: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)',
                lineColor: 'var(--highcharts-neutral-color-100)',
                upColor: 'var(--highcharts-background-color)'
            },
            flags: {
                states: {
                    hover: {
                        lineColor: 'var(--highcharts-neutral-color-100)',
                        fillColor: 'var(--highcharts-highlight-color-20)'
                    },
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)',
                fillColor: 'var(--highcharts-background-color)',
                style: {
                    color: 'var(--highcharts-neutral-color-100)'
                }
            },
            arearange: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            areasplinerange: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            boxplot: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)',
                fillColor: 'var(--highcharts-background-color)'
            },
            bubble: {
                marker: {
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            columnrange: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            columnpyramid: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            errorbar: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)',
                fillColor: 'var(--highcharts-background-color)',
                color: 'var(--highcharts-neutral-color-100)'
            },
            gauge: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                dataLabels: {
                    borderColor: 'var(--highcharts-neutral-color-20)'
                },
                dial: {
                    backgroundColor: 'var(--highcharts-neutral-color-100)',
                    borderColor: 'var(--highcharts-neutral-color-20)'
                },
                pivot: {
                    borderColor: 'var(--highcharts-neutral-color-100)',
                    backgroundColor: 'var(--highcharts-background-color)'
                }
            },
            packedbubble: {
                marker: {
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            polygon: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            waterfall: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-neutral-color-80)',
                lineColor: 'var(--highcharts-neutral-color-80)'
            },
            scatter3d: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            map: {
                states: {
                    hover: {
                        borderColor: 'var(--highcharts-neutral-color-60)'
                    },
                    select: {
                        color: 'var(--highcharts-neutral-color-20)'
                    }
                },
                nullColor: 'var(--highcharts-neutral-color-3)',
                borderColor: 'var(--highcharts-neutral-color-10)'
            },
            mapline: {
                states: {
                    hover: {
                        borderColor: 'var(--highcharts-neutral-color-60)'
                    },
                    select: {
                        color: 'var(--highcharts-neutral-color-20)'
                    }
                },
                nullColor: 'var(--highcharts-neutral-color-3)',
                borderColor: 'var(--highcharts-neutral-color-10)'
            },
            mappoint: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                dataLabels: {
                    style: {
                        color: 'var(--highcharts-neutral-color-100)'
                    }
                }
            },
            mapbubble: {
                marker: {
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            heatmap: {
                marker: {
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                nullColor: 'var(--highcharts-neutral-color-3)'
            },
            xrange: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            gantt: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            sankey: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            dependencywheel: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            funnel: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            pyramid: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            histogram: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            bellcurve: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                }
            },
            item: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                borderColor: 'var(--highcharts-background-color)'
            },
            organization: {
                states: {
                    select: {
                        color: 'var(--highcharts-neutral-color-20)',
                        borderColor: 'var(--highcharts-neutral-color-100)'
                    }
                },
                borderColor: 'var(--highcharts-neutral-color-60)',
                link: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            },
            solidgauge: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                dataLabels: {
                    borderColor: 'var(--highcharts-neutral-color-20)'
                },
                dial: {
                    backgroundColor: 'var(--highcharts-neutral-color-100)',
                    borderColor: 'var(--highcharts-neutral-color-20)'
                },
                pivot: {
                    borderColor: 'var(--highcharts-neutral-color-20)',
                    backgroundColor: 'var(--highcharts-neutral-color-100)'
                }
            },
            timeline: {
                marker: {
                    lineColor: 'var(--highcharts-background-color)',
                    states: {
                        select: {
                            fillColor: 'var(--highcharts-neutral-color-20)',
                            lineColor: 'var(--highcharts-neutral-color-100)'
                        }
                    }
                },
                dataLabels: {
                    backgroundColor: 'var(--highcharts-background-color)',
                    borderColor: 'var(--highcharts-neutral-color-40)',
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            treemap: {
                states: {
                    hover: {
                        borderColor: 'var(--highcharts-neutral-color-40)'
                    }
                },
                borderColor: 'var(--highcharts-neutral-color-10)'
            },
            sunburst: {
                states: {
                    hover: {
                        borderColor: 'var(--highcharts-neutral-color-40)'
                    }
                },
                borderColor: 'var(--highcharts-neutral-color-10)'
            },
            treegraph: {
                states: {
                    hover: {
                        borderColor: 'var(--highcharts-neutral-color-40)'
                    }
                },
                borderColor: 'var(--highcharts-neutral-color-10)',
                link: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            }
        },
        legend: {
            borderColor: 'var(--highcharts-neutral-color-40)',
            navigation: {
                activeColor: 'var(--highcharts-highlight-color-100)',
                inactiveColor: 'var(--highcharts-neutral-color-20)'
            },
            itemStyle: {
                color: 'var(--highcharts-neutral-color-80)'
            },
            itemHoverStyle: {
                color: 'var(--highcharts-neutral-color-100)'
            },
            itemHiddenStyle: {
                color: 'var(--highcharts-neutral-color-60)'
            },
            title: {
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            bubbleLegend: {
                labels: {
                    style: {
                        color: 'var(--highcharts-neutral-color-100)'
                    }
                }
            }
        },
        loading: {
            style: {
                backgroundColor: 'var(--highcharts-background-color)'
            }
        },
        tooltip: {
            backgroundColor: 'var(--highcharts-background-color)',
            style: {
                color: 'var(--highcharts-neutral-color-80)'
            }
        },
        credits: {
            style: {
                color: 'var(--highcharts-neutral-color-40)'
            }
        },
        xAxis: {
            labels: {
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            title: {
                style: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            },
            minorGridLineColor: 'var(--highcharts-neutral-color-5)',
            minorTickColor: 'var(--highcharts-neutral-color-40)',
            lineColor: 'var(--highcharts-neutral-color-80)',
            gridLineColor: 'var(--highcharts-neutral-color-10)',
            tickColor: 'var(--highcharts-neutral-color-80)',
            grid: {
                borderColor: 'var(--highcharts-neutral-color-20)'
            }
        },
        yAxis: {
            labels: {
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            title: {
                style: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            },
            minorGridLineColor: 'var(--highcharts-neutral-color-5)',
            minorTickColor: 'var(--highcharts-neutral-color-40)',
            lineColor: 'var(--highcharts-neutral-color-80)',
            gridLineColor: 'var(--highcharts-neutral-color-10)',
            tickColor: 'var(--highcharts-neutral-color-80)',
            stackLabels: {
                style: {
                    color: 'var(--highcharts-neutral-color-100)'
                }
            },
            grid: {
                borderColor: 'var(--highcharts-neutral-color-20)'
            }
        },
        navigator: {
            handles: {
                backgroundColor: 'var(--highcharts-neutral-color-5)',
                borderColor: 'var(--highcharts-neutral-color-40)'
            },
            outlineColor: 'var(--highcharts-neutral-color-40)',
            xAxis: {
                gridLineColor: 'var(--highcharts-neutral-color-10)',
                labels: {
                    style: {
                        color: 'var(--highcharts-neutral-color-100)'
                    }
                }
            }
        },
        rangeSelector: {
            inputStyle: {
                color: 'var(--highcharts-highlight-color-80)'
            },
            labelStyle: {
                color: 'var(--highcharts-neutral-color-60)'
            }
        },
        scrollbar: {
            barBackgroundColor: 'var(--highcharts-neutral-color-20)',
            barBorderColor: 'var(--highcharts-neutral-color-20)',
            buttonArrowColor: 'var(--highcharts-neutral-color-80)',
            buttonBackgroundColor: 'var(--highcharts-neutral-color-10)',
            buttonBorderColor: 'var(--highcharts-neutral-color-20)',
            trackBorderColor: 'var(--highcharts-neutral-color-20)'
        },
        pane: {
            background: {
                borderColor: 'var(--highcharts-neutral-color-20)',
                backgroundColor: 'var(--highcharts-neutral-color-5)'
            }
        },
        zAxis: {
            labels: {
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            title: {
                style: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            },
            minorGridLineColor: 'var(--highcharts-neutral-color-5)',
            minorTickColor: 'var(--highcharts-neutral-color-40)',
            lineColor: 'var(--highcharts-neutral-color-80)',
            gridLineColor: 'var(--highcharts-neutral-color-10)',
            tickColor: 'var(--highcharts-neutral-color-80)'
        },
        colorAxis: {
            labels: {
                style: {
                    color: 'var(--highcharts-neutral-color-80)'
                }
            },
            title: {
                style: {
                    color: 'var(--highcharts-neutral-color-60)'
                }
            },
            minorGridLineColor: 'var(--highcharts-neutral-color-5)',
            minorTickColor: 'var(--highcharts-neutral-color-40)',
            lineColor: 'var(--highcharts-neutral-color-80)',
            gridLineColor: 'var(--highcharts-background-color)',
            tickColor: 'var(--highcharts-neutral-color-80)',
            marker: {
                color: 'var(--highcharts-neutral-color-40)'
            },
            minColor: 'var(--highcharts-highlight-color-10)',
            maxColor: 'var(--highcharts-highlight-color-100)'
        },
        mapNavigation: {
            buttonOptions: {
                style: {
                    color: 'var(--highcharts-neutral-color-60)'
                },
                theme: {
                    fill: 'var(--highcharts-background-color)',
                    stroke: 'var(--highcharts-neutral-color-10)'
                }
            }
        },
        accessibility: {
            keyboardNavigation: {
                focusBorder: {
                    style: {
                        color: 'var(--highcharts-highlight-color-80)'
                    }
                }
            }
        },
        drilldown: {
            activeAxisLabelStyle: {
                color: 'var(--highcharts-highlight-color-100)'
            },
            activeDataLabelStyle: {
                color: 'var(--highcharts-highlight-color-100)'
            }
        },
        annotations: {
            labelOptions: {
                borderColor: 'var(--highcharts-neutral-color-100)',
                backgroundColor: 'color-mix(in srgb, ' +
                    'var(--highcharts-neutral-color-100) 75%, transparent)'
            },
            controlPointOptions: {
                style: {
                    fill: 'var(--highcharts-background-color)',
                    stroke: 'var(--highcharts-neutral-color-100)'
                }
            },
            types: {
                elliottWave: {
                    labelOptions: {
                        style: {
                            color: 'var(--highcharts-neutral-color-60)'
                        }
                    }
                },
                fibonacci: {
                    typeOptions: {
                        lineColor: 'var(--highcharts-neutral-color-40)'
                    },
                    labelOptions: {
                        style: {
                            color: 'var(--highcharts-neutral-color-60)'
                        }
                    }
                },
                fibonacciTimeZones: {
                    typeOptions: {
                        line: {
                            stroke: 'var(--highcharts-neutral-color-80)'
                        }
                    }
                },
                verticalLine: {
                    labelOptions: {
                        style: {
                            color: 'var(--highcharts-neutral-color-60)'
                        }
                    }
                },
                measure: {
                    typeOptions: {
                        label: {
                            style: {
                                color: 'var(--highcharts-neutral-color-60)'
                            }
                        }
                    }
                }
            },
            shapeOptions: {
                fill: 'color-mix(in srgb, ' +
                    'var(--highcharts-neutral-color-100) 75%, transparent)',
                stroke: 'color-mix(in srgb, ' +
                    'var(--highcharts-neutral-color-100) 75%, transparent)'
            }
        },
        navigation: {
            buttonOptions: {
                symbolFill: 'var(--highcharts-neutral-color-60)',
                symbolStroke: 'var(--highcharts-neutral-color-60)',
                theme: {
                    fill: 'var(--highcharts-background-color)'
                }
            },
            menuStyle: {
                background: 'var(--highcharts-background-color)'
            },
            menuItemStyle: {
                color: 'var(--highcharts-neutral-color-80)'
            },
            menuItemHoverStyle: {
                background: 'var(--highcharts-neutral-color-5)'
            }
        }
    };
    /* *
     *
     *  Functions
     *
     * */
    /**
     * Apply the theme.
     */
    function apply() {
        // Add a style sheet
        const style = document.createElement('style');
        style.nonce = 'highcharts';
        style.innerText = styleSheet;
        style.id = 'highcharts-adaptive-theme';
        document.getElementsByTagName('head')[0].appendChild(style);
        // Apply the theme
        setOptions(DynamicDefaultTheme.options);
        // Copy it over to the shadow DOM of each chart (#23967)
        addEvent((highcharts_Chart_commonjs_highcharts_Chart_commonjs2_highcharts_Chart_root_Highcharts_Chart_default()), 'afterGetContainer', function () {
            const shadowRoot = this.container
                .getRootNode().host?.shadowRoot;
            if (shadowRoot &&
                !shadowRoot.getElementById('highcharts-adaptive-theme')) {
                const adaptiveStyle = style.cloneNode(true);
                shadowRoot.appendChild(adaptiveStyle);
            }
        });
    }
    DynamicDefaultTheme.apply = apply;
})(DynamicDefaultTheme || (DynamicDefaultTheme = {}));
/* *
 *
 *  Default Export
 *
 * */
/* harmony default export */ const Adaptive = (DynamicDefaultTheme);

;// ./code/es-modules/masters/themes/adaptive.src.js




(highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default()).theme = Adaptive.options;
Adaptive.apply();
/* harmony default export */ const adaptive_src = ((highcharts_commonjs_highcharts_commonjs2_highcharts_root_Highcharts_default()));

__webpack_exports__ = __webpack_exports__["default"];
/******/ 	return __webpack_exports__;
/******/ })()
;
});