/* *
 *
 *  Arc diagram module
 *
 *  (c) 2021-2026 Highsoft AS
 *  Author: Piotr Madej, Grzegorz Blachliński
 *
 *  Integration of this software requires a license.
 *  - For commercial use, see www.highcharts.com/license
 *  - For non-commercial, see www.highcharts.com/license-eula
 *
 *
 * */
export {};
